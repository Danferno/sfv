**** Installing SFV ****
*** Method 1: Installer (requires admin rights)
1. Set up the example folder
	a. Open smallfileversioning_foldersToVersion.txt
	b. Replace #sfv-folder# in line 5 by the location of your smallfileversioning folder. E.g. c:/ado/sfv
2. Installing sfv
	a. Rightclick on smallfileversioning_installer.ps1
	b. Select [Run with Powershell]
	c. You may be prompted for admin rights, some errors in red may appear, but they should be ignorable
	d. Close the window
	e. There should now be an sfv logo in your taskbar (where the wifi icon etc is, you may need to expand the list through the < icon)

---------------------------------------------------------------------------------------------------------------------------------------
	
*** Method 2: Manual task schedule (usually no admin rights required)
1. Set up the example folder
	a. Open smallfileversioning_foldersToVersion.txt
	b. Replace #sfv-folder# in line 5 by the location of your smallfileversioning folder. E.g. c:/ado/sfv
2. Installing sfv
	a. Right click on Small File Versioning.xml
	b. Select [Open With]-[Notepad] (or any other text editor)
	c. Replace #sfv-folder# by the location of your smallfileversioning folder. (It's a few lines from the bottom)
	d. Open the task scheduler (Windows Key -> Task Scheduler or Schedule Task)
	e. In the left pane, select [Task Scheduler Library]
	f. In the right pane, select [Import Task...]
	g. Select [Small File Versioning.xml] (in your sfv folder)
	h. Press [OK]. If at this point you are prompted for login details, you probably need admin rights after all. Either start the Task Scheduler as administrator, or just run the installer of method 1.
	i. Look for the "Small File Versioning" task in the middle pane. Select it.
	j. In the right pane, select [Run]. A blue screen should pop up and disappear again.
	
---------------------------------------------------------------------------------------------------------------------------------------

**** Setting up your folders
3. Set up your own folders
	a. Rightclick the SFV icon
	b. Select [Folders To Backup ...]
	c. Add as many folder paths as you like. You can delete the example folder.
	d. Close the text editor.
	
---------------------------------------------------------------------------------------------------------------------------------------

**** Changing the settings
4. Change the settings
	a. Rightclick the SFV icon
	b. Select [Settings ...]
	c. Change the suffix of the backup folder to your liking
	d. Change sleep duration between checks. The lower, the more often files are copied. The default is 900 seconds (15 minutes). Set it to 20 or so to test if SFV is doing what you expect it to (less waiting).
	
---------------------------------------------------------------------------------------------------------------------------------------

**** Some important things to know
- SFV does not backup files in subfolders
- If you press "Quit" in the icon, it will take until the next iteration of sfv before the actual backup process starts (e.g. if you had set a 900 seconds delay, it will take between 0 and 900 seconds before the underlying process stops)


**** Contact information in case of bugs or happy user
jesse (dot) wursten (at) kuleuven (dot) be
https://sites.google.com/view/jessewursten/home
