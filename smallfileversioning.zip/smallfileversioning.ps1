﻿# Changelog
## 19-06-21 / 1.2.0: Now comes with installer (adds to task scheduler, starts process). Expanded contextmenu.
## 19-06-20: Merged icon script into main script. Created custom icon.
## 19-06-05: Added notification icon -> Start/Stop capacity (in other script)
## 19-05-28: Now handles missing folders more gracefully


# Technicalities
## Obtain script path
$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition

## Start icon
Start-Job  -Name Icon -ArgumentList $scriptPath -ScriptBlock {
    # Identify script path and start log
    $scriptPath = $args[0]
    #Start-Transcript -Path "$scriptPath/smallfileversioning_log2.log" -Append > $null

    # Load assemblies
    ## Icon
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    # Start notification icon
    ## Define a form (you need a runspace for the icon to work in)
    $form = New-Object System.Windows.Forms.Form
    $form.ShowInTaskbar = $false
    $form.FormBorderStyle = 'SizableToolWindow'
    #$form.WindowState = [System.Windows.WindowState]::Minimized
    $form.StartPosition = "manual"
    $form.Location = New-Object System.Drawing.Size(-60,-60)
    $form.size = New-Object System.Drawing.Size(50,50)

    ## Define buttons
    ### Pause button (option once you click)
    $MenuItem_pause = New-Object System.Windows.Forms.MenuItem
    $MenuItem_pause.Text = "Pause backup"
    $MenuItem_pause.add_click({
        # Replace pause button by resume button
        $ContextMenu.MenuItems.Add(0, $MenuItem_resume)   > $null
        $ContextMenu.MenuItems.Remove($MenuItem_pause) > $null
    
        # Tell program to pause
        if(Test-Path "$scriptPath"){
            Out-File -FilePath "$scriptPath/smallfileversioning_startstop.log" -InputObject "pause" -NoNewline
            [console]::beep(500,300)
            Write-Output "pause"
        }

        else{[console]::beep(2500,300)}
    })

    ### Resume button (option once you click)
    $MenuItem_resume = New-Object System.Windows.Forms.MenuItem
    $MenuItem_resume.Text = "Resume backup"
    $MenuItem_resume.add_click({
        # Replace resume button by pause button
        $ContextMenu.MenuItems.Remove($MenuItem_resume) > $null
        $ContextMenu.MenuItems.Add(0, $MenuItem_pause)     > $null

        # Tell program to resume
        if(Test-Path "$scriptPath"){
            Out-File -FilePath "$scriptPath/smallfileversioning_startstop.log" -InputObject "resume" -NoNewline
            [console]::beep(500,300)
            Write-Output "resume"
        }

        else{[console]::beep(2500,300)}
    })

    ### Exit button
    $MenuItem_exit = New-Object System.Windows.Forms.MenuItem
    $MenuItem_exit.Text = "Quit"
    $MenuItem_exit.add_click({
        $NotifyIcon.Visible = $False
        $form.close()
        $NotifyIcon.Dispose()

        # Tell program to exit
        if(Test-Path "$scriptPath"){
            Out-File -FilePath "$scriptPath/smallfileversioning_startstop.log" -InputObject "exit" -NoNewline
            [console]::beep(500,300)
            [console]::beep(550,300)
            [console]::beep(600,300)
            Write-Output "exit"
        }

        else{[console]::beep(2500,300)}
    })

    ### Settings
    $MenuItem_config = New-Object System.Windows.Forms.MenuItem
    $MenuItem_config.Text = "Settings ..."
    $MenuItem_config.add_click({
        # Open settings GUI if scriptPath exists
        if(Test-Path "$scriptPath"){
            [console]::beep(500,300)
            Write-Output "Opening config file."
            Invoke-Item "$scriptPath/smallfileversioning_config.txt"
        }

        else{[console]::beep(2500,300)}
    })

    $MenuItem_folders = New-Object System.Windows.Forms.MenuItem
    $MenuItem_folders.Text = "Folders to Backup ..."
    $MenuItem_folders.add_click({
        # Open settings GUI if scriptPath exists
        if(Test-Path "$scriptPath"){
            [console]::beep(500,300)
            Write-Output "Opening folders file."
            Invoke-Item "$scriptPath/smallfileversioning_foldersToVersion.txt"
        }

        else{[console]::beep(2500,300)}
    })

    $MenuItem_log = New-Object System.Windows.Forms.MenuItem
    $MenuItem_log.Text = "Log file ..."
    $MenuItem_log.add_click({
        # Open log file if scriptPath exists
        if(Test-Path "$scriptPath"){
            [console]::beep(500,300)
            Write-Output "Opening log file."
            Invoke-Item "$scriptPath/smallfileversioning_log.log"
        }

        else{[console]::beep(2500,300)}
    })

    ## Define Context menu (container for what you get once you click)
    $ContextMenu = New-Object System.Windows.Forms.ContextMenu
    $ContextMenu.MenuItems.Add($MenuItem_pause)  > $null
    $ContextMenu.MenuItems.Add("-")  > $null
    $ContextMenu.MenuItems.Add($MenuItem_config)  > $null
    $ContextMenu.MenuItems.Add($MenuItem_log)  > $null
    $ContextMenu.MenuItems.Add($MenuItem_folders)  > $null
    $ContextMenu.MenuItems.Add("-")  > $null
    $ContextMenu.MenuItems.Add($MenuItem_exit)   > $null

    ## Draw Icon
    ### Initialise object
    $bmp = New-Object System.Drawing.Bitmap(16,16)
    $iconInProgress = [System.Drawing.Graphics]::FromImage($bmp)
    $pen = New-Object Drawing.Pen White

    ### S
    $iconInProgress.drawline($pen,2,0,6,0)
    $iconInProgress.drawline($pen,0,2,2,0)
    
    $iconInProgress.drawline($pen,0,2,0,5)
    $iconInProgress.drawline($pen,2,7,0,5)

    $iconInProgress.drawline($pen,2,7,4,7)
    $iconInProgress.drawline($pen,6,9,4,7)

    $iconInProgress.drawline($pen,6,9,6,13)
    $iconInProgress.drawline($pen,6,13,4,15)
    $iconInProgress.drawline($pen,4,15,0,15)
    
    ### V
    $iconInProgress.drawline($pen,12,15,9,8)
    $iconInProgress.drawline($pen,12,15,15,8)

    ### F
    $iconInProgress.drawline($pen,11,0,11,7)
    $iconInProgress.drawline($pen,11,0,15,0)
    $iconInProgress.drawline($pen,11,4,13,4)

    ### Turn into Icon
    $icon = [System.Drawing.Icon]::FromHandle($bmp.GetHicon())

    ## Define Notify icon (what you see)
    $NotifyIcon= New-Object System.Windows.Forms.NotifyIcon
    #$NotifyIcon.Icon = [Drawing.Icon]::ExtractAssociatedIcon((Get-Command powershell).Path)
    $NotifyIcon.Icon = $icon
    $NotifyIcon.ContextMenu = $ContextMenu
    $NotifyIcon.GetType().GetMethod("ShowContextMenu",[System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic).Invoke($NotifyIcon,$null)
    $NotifyIcon.Visible = $True

    ## Start the form
    $form.ShowDialog()

    # Remove the icon on program finish
    $NotifyIcon.Dispose() > $Null
} > $null

## Default mode is for the script to run
if(Test-Path "$scriptPath/smallfileversioning_startstop.log"){
    Out-File -FilePath "$scriptPath/smallfileversioning_startstop.log" -InputObject "resume" -NoNewline
}

## Repeat every X seconds
do {
    # Check if script should continue running
    if(Test-Path "$scriptPath/smallfileversioning_startstop.log"){
        ## Load script status
        $scriptRunningStatus = Get-Content -Path "$scriptPath/smallfileversioning_startstop.log"
        
        ## Resume
        if($scriptRunningStatus -eq "pause"){
            "Script set to pause, will check for updates every 10 seconds"
            while($scriptRunningStatus -eq "pause"){
                Start-Sleep 10
                $scriptRunningStatus = Get-Content -Path "$scriptPath/smallfileversioning_startstop.log"
            }
        }
        if($scriptRunningStatus -eq "exit"){
            "Termination of script requested."
            exit
        }
    }


    # Obtain paths from folderToVersion file
    ## Sleep if script path doesn't exist
    while(!(test-path $scriptPath)){
        "Script Path doesn't exist, sleeping for 5 minutes."
        sleep 300
    }
    
    ## Obtain paths if it does
    $paths = Get-Content "$scriptPath\smallfileversioning_foldersToVersion.txt" | Select-Object -Skip 4

    # Obtain settings from config file
    Get-Content "$scriptPath/smallfileversioning_config.txt" |
    ForEach-Object `
        -begin {$sfv_settings = @{}}`
        -process {
            $line = [regex]::split($_,'=')
            if(($line[0].CompareTo("") -ne 0) -and ($line[0].StartsWith("*") -ne $True)){$sfv_settings.Add($line[0].Trim(), $line[1].Trim())}
        }

    # Open log
    Start-Transcript -Path "$scriptPath/smallfileversioning_log.log" -Append > $null

    # Display date
    Get-Date -Format g

    # Loop over folders you want to back up
    foreach ($path in $paths){
        If(!(Test-Path $path)){
            "Cannot access path: $path"
            "Skipping this folder."
            continue
        }

        $parentPath = Split-Path -parent $path
        $folderToBackupName = Split-Path -Leaf $path
        $versionsFolderName = $folderToBackupName + $sfv_settings.folderSuffix
        $versionsFolder = "$parentPath/$versionsFolderName"

        # Create logfile and backup folder if it doesn't exist
        If(!(test-path $versionsFolder)){
            md -Path $versionsFolder > $null
            md -Path $versionsFolder/Logs > $null
        }

        # Loop over files in folder to perform backup
        foreach ($file in Get-ChildItem $path){
            # Obtain file name and lastwrite time
            $fileName = $file.Name        # File Name
            $fileFullName = $file.FullName        # File Path/Name
            $fileLastWrite = $file.LastWriteTime.GetDateTimeFormats('u')   # File Last write time
            $fileNewName = $file.BaseName + "__" + $file.LastWriteTime.tostring("yyyy_MM_dd_HHmmss") + $file.Extension
    
            # Save last write if this is the first time + backup
            If(!(Test-Path $versionsFolder/Logs/$fileName.log)){
                Out-File -FilePath $versionsFolder/Logs/$fileName.log -InputObject $fileLastWrite -NoNewline

                # Backup
                Copy-Item -Path $fileFullName -Destination $versionsFolder/$fileNewName
                "File backed up to $versionsFolder/$fileNewName"
            }

            # Read last write if this is not the first time
            Else{
                $filePreviousLastWrite = Get-Content -Path $versionsFolder/Logs/$fileName.log
        
                # Compare last write times
                ## Unchanged -> Do Nothing
                If($fileLastWrite -eq $filePreviousLastWrite){
                }

                ## Changed -> Backup + Update logfile
                Else{
                    # Backup
                    Copy-Item -Path $fileFullName -Destination $versionsFolder/$fileNewName

                    # Replace logfile
                    Out-File -FilePath $versionsFolder/Logs/$fileName.log -InputObject $fileLastWrite -NoNewline
                    "Changed file backed up to $versionsFolder/$fileNewName"
                }
            }
        }
        "OK: $path"
    }

    # Sleep 5 minutes
    Write-Host "Completed loop, going to sleep for $($sfv_settings.sleepTime) seconds."
    Write-Host ""
    start-sleep -Seconds $sfv_settings.sleepTime
}until($infinity)
