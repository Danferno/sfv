﻿# This script adds SFV to the task scheduler such that it starts at user login
# Obtain current user
$principal = New-ScheduledTaskPrincipal -UserId (Get-CimInstance –ClassName Win32_ComputerSystem | Select-Object -expand UserName)

# Elevate to admin
if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit 
}

# Obtain info
$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition

# Generate task"
$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument @"
-WindowStyle Hidden  -NoProfile -ExecutionPolicy bypass -File "$scriptPath\smallfileversioning.ps1"
"@
$trigger = New-ScheduledTaskTrigger -AtLogOn
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit '00:00:00'  -AllowStartIfOnBatteries
$name = 'Small File Versioning'

# Verify task doesn't exist yet
$taskExistsAlready = Get-ScheduledTask -TaskName $name | Where-Object {$_.TaskName -like $name}
if ($taskExistsAlready) {
    "It appears the task already exists. Answer Y below to remove it so it can be replaced"
    ""
    Unregister-ScheduledTask -TaskName $name
}

# Register task
""
"Adding SFV to Task Scheduler such that it starts on user log on"
Register-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -Principal $principal -TaskName $name -Description 'Tool that makes automatic backups of all files in specified folders.'

# Start SFV
""
"Starting Task."
Start-ScheduledTask -TaskName $name

"Done. You can now close this window."

start-sleep 900